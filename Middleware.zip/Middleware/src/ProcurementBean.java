
import java.util.ArrayList;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import Orders.ItemType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "orderType", propOrder = {
    "name",
    "items",
    "total",
    "hst",
    "grandTotal"
})
@XmlRootElement
public class ProcurementBean {
	@XmlElement(required = true)
    protected String name;
	@XmlAttribute(name = "id", required = true)
    @XmlSchemaType(name = "positiveInteger")
	protected int procurementID;
	@XmlElement(name="items", required = true)
	protected ArrayList<ItemType> items;
    @XmlAttribute(name = "submitted")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar submitted;
    @XmlElement(required = true)
    protected double total;
    @XmlElement(name = "HST", required = true)
    protected double hst;
    @XmlElement(required = true)
    protected double grandTotal;
    
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getProcurementID() {
		return procurementID;
	}
	public void setProcurementID(int procurementID) {
		this.procurementID = procurementID;
	}
	public ArrayList<ItemType> getItems() {
		if (items == null) {
            items = new ArrayList<ItemType>();
        }
        return this.items;
	}
	public void setItems(ArrayList<ItemType> items) {
		this.items = items;
	}
	public XMLGregorianCalendar getSubmitted() {
		return submitted;
	}
	public void setSubmitted(XMLGregorianCalendar submitted) {
		this.submitted = submitted;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public double getHst() {
		return hst;
	}
	public void setHst(double hst) {
		this.hst = hst;
	}
	public double getGrandTotal() {
		return grandTotal;
	}
	public void setGrandTotal(double grandTotal) {
		this.grandTotal = grandTotal;
	}
	@Override
	public String toString() {
		return "ProcurementBean [name=" + name + ", procurementID=" + procurementID + ", items=" + items
				+ ", submitted=" + submitted + ", total=" + total + ", hst=" + hst + ", grandTotal=" + grandTotal + "]";
	}
}

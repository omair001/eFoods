import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import Orders.ItemType;
import Orders.ObjectFactory;
import Orders.OrderType;

public class MiddleWare {
	private final String poPath = System.getProperty("user.home") + "/PO/";
	private final String orderPath = System.getProperty("user.dir") + "/POrders/";
	private final double HST = 0.13;
	private static ObjectFactory factory = new ObjectFactory();
	private boolean created = false;
	private static DecimalFormat df2 = new DecimalFormat(".##");

	/**
	 * @Description creates purchase order
	 * 
	 * @param allProducts
	 *            is a TreeMap of names that map to ItemBought objects
	 * @param name
	 *            of the user
	 * @param username
	 *            of user
	 * 
	 * @throws JAXBException,
	 *             DatatypeConfigurationException
	 */
	public void process() throws DatatypeConfigurationException, JAXBException {
		ProcurementBean procurement = new ProcurementBean();
		procurement.setName("EFoods");
		double total = 0;
		final File folder = new File(orderPath);
		final File folder1 = new File(poPath);
		int number = 0;
		OrderType ord = factory.createOrderType();

		// creates destination path if it doesn't exist
		File Path = new File(orderPath);
		if (!Path.exists()) {
			try {
				Path.getParentFile().mkdirs();
				Path.mkdirs();
			} catch (Exception e) {
				throw e;
			}
		}
		ArrayList<ItemType> items = procurement.getItems();
		GregorianCalendar cal = new GregorianCalendar();
		XMLGregorianCalendar date2 = DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR),
				cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);
		procurement.setSubmitted(date2);

		List<String> itemNames = new ArrayList<String>();

		String[] fname = new String[3];
		for (final File fileEntry : folder.listFiles()) {
			fname = fileEntry.getName().split("\\.");
			fname = fname[0].split("_");
		}
		if (fname[1] != null) {
			number = Integer.parseInt(fname[1]);
		}
		number += 1;

		procurement.setProcurementID(number);

		fname = new String[3];
		// goes through each order checks if items exist in list
		// if not, set item and add
		// otherwise update
		for (final File fileEntry : folder1.listFiles()) {
			try {
				String done = "Done";
				if (fileEntry.getName().toLowerCase().contains(done.toLowerCase())) {
				} else {
					JAXBContext jc = JAXBContext.newInstance(ord.getClass());
					Unmarshaller um = jc.createUnmarshaller();
					ord = (OrderType) um.unmarshal(new File(poPath + fileEntry.getName()));
					List<ItemType> it = ord.getItems().getItem();
					for (ItemType process : it) {
						if (!itemNames.contains(process.getName())) {
							ItemType nitem = new ItemType();
							nitem.setName(process.getName());
							nitem.setPrice(process.getPrice());
							nitem.setExtended(process.getExtended());
							nitem.setNumber(process.getNumber());
							nitem.setQuantity(process.getQuantity());
							items.add(nitem);
							itemNames.add(nitem.getName());
							total += nitem.getExtended().doubleValue();
							created = true;
						} else {
							int index = itemNames.indexOf(process.getName());
							ItemType nitem = items.get(index);
							nitem.setQuantity(nitem.getQuantity().add(process.getQuantity()));
							nitem.setExtended(nitem.getExtended().add(process.getExtended()));
							items.set(index, nitem);
							total += nitem.getExtended().doubleValue();
							created = true;
						}
					}

					fname = fileEntry.getName().split("\\.");
					fileEntry.renameTo(new File(poPath + fname[0] + "_Done.xml"));
				}
			} catch (Exception e) {
				System.out.println(e.getStackTrace());
			}
		}
		procurement.setTotal(Double.parseDouble(df2.format(total)));
		procurement.setHst(Double.parseDouble(df2.format(procurement.getTotal() * HST)));
		procurement.setGrandTotal(Double.parseDouble(df2.format(procurement.getHst() + procurement.getTotal())));
		// if something is added then creates a new report, else it doesn't.
		if (created == true) {
			JAXBContext jc = JAXBContext.newInstance(procurement.getClass());
			Marshaller marsh = jc.createMarshaller();
			marsh.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marsh.marshal(procurement, new File(orderPath+"ProcurementOrder_"
					+ new DecimalFormat("00").format(procurement.getProcurementID()) + ".xml"));
		}
	}

	public static void main(String[] args) {

		MiddleWare mid = new MiddleWare();
		try {
			mid.process();
		} catch (DatatypeConfigurationException | JAXBException e) {
			e.printStackTrace();
		}
	}
}
